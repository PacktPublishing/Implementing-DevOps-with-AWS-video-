var i;

console.log("Start!"); \\Printing the word start

for(i=10; i<=20; i++){  \\Setting i as 10 and incrementing it till 20
	console.log("i is " +i);
}

console.log("Now i is:" +i); \\Printing the final value before we end

console.log("End!");